package com.example.myapplication;

import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private Button selectMovieButton;
    private TextView movieInfoTextView;
    private Movie[] movies;
    private boolean[] shownMovies; // Массив для отслеживания показанных фильмов
    private Random random;
    private int remainingMovies; // Количество оставшихся фильмов

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        selectMovieButton = findViewById(R.id.button);
        movieInfoTextView = findViewById(R.id.filmInfo);
        loadMovies();

        random = new Random();
        remainingMovies = movies.length;
        shownMovies = new boolean[movies.length];
    }
    public void onClick(View v) {
        displayRandomMovie();
    }

    private void loadMovies() {
        InputStream inputStream = getResources().openRawResource(R.raw.movies);
        InputStreamReader reader = new InputStreamReader(inputStream);
        Gson gson = new Gson();
        movies = gson.fromJson(reader, Movie[].class);
        for (Movie m : movies) {
            Log.d("hh", m.toString());
        }
    }

    private void displayRandomMovie() {
        if (remainingMovies == 0) {
            movieInfoTextView.setText("Очень жаль, нам больше нечего предложить!");
            return;
        }
        int randomIndex;
        do {
            randomIndex = random.nextInt(movies.length);
        } while (shownMovies[randomIndex]); // до тех пор, пока не найдём не показанный фильм

        Movie movie = movies[randomIndex];
        movieInfoTextView.setText(movie.toString());
        shownMovies[randomIndex] = true; // Установка флага о том, что этот фильм был показан
        remainingMovies--; // Уменьшение количества оставшихся фильмов
    }
}