package com.example.myapplication;

import java.util.List;

public class Movie {
    String title;
    int year;
    String director;
    String genre;
    String description;
    double rating;


@Override
    public String toString(){
        return "Название: " + title + "\n" +
                "\nГод: " + year + "\n" +
                "\nРежиссер: " + director + "\n" +
                "\nЖанр: " + genre + "\n" +
                "\nОценка на Кинопоиске: " + rating + "\n" +
                "\nОписание: " + description;
    }


}
