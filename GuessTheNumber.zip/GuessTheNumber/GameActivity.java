package com.example.guessthenumber;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class GameActivity extends AppCompatActivity {
    private int begin, end, mid;
    private TextView messageText;
    private Button yesButton;
    private Button noButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_game);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        messageText = findViewById(R.id.message);
        yesButton = findViewById(R.id.yes);
        noButton = findViewById(R.id.no);

        Intent i = getIntent();
        begin = i.getIntExtra("begin", 0);
        end = i.getIntExtra("end", 100); // Устанавливаем значение по умолчанию для end, begin

        if (begin > end) {
            // Если начальный диапазон неверный, выводим сообщение об ошибке
            messageText.setText("Неверный диапазон чисел. Пожалуйста, попробуйте снова.");
            yesButton.setEnabled(false);
            noButton.setEnabled(false);
            return;
        }
        askQuestion();
    }

    private void askQuestion() {
        if (begin == end) {
            messageText.setText("Ваше число равно " + begin + " ?");
        } else {
            mid = (begin + end) / 2;
            messageText.setText("Ваше число меньше или равно " + mid + "?");
        }
    }

    public void onYesNoClick(View view) {
        if (begin == end) {
            if (view.getId() == R.id.yes) {
                messageText.setText("Ура, я угадал! Вы загадали число " + begin);
                yesButton.setEnabled(false);
                noButton.setEnabled(false);
            } else if (view.getId() == R.id.no) {
                messageText.setText("Ой! Я не угадал Ваше число. Попробуйте снова.");
                yesButton.setEnabled(false);
                noButton.setEnabled(false);
            }
        } else {
            // Сужаем диапазон на основании ответа игрока
            if (view.getId() == R.id.yes) {
                end = mid; // Сужаем верхнюю границу
            } else if (view.getId() == R.id.no) {
                begin = mid + 1; // Сужаем нижнюю границу
            }
            askQuestion();
        }
    }
}