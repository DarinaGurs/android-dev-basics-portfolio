package com.example.arrayadapter;

public enum Sex {
    MAN, WOMAN, UNKNOWN
}