package com.example.arrayadapter;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

public class UserListAdapter extends BaseAdapter {
    private Context ctx;
    private ArrayList<User> users;
    private int selectedPosition = -1; // Индекс выделенного элемента, -1 - нет выделенных

    public UserListAdapter(Context ctx, ArrayList<User> users) {
        this.ctx = ctx;
        this.users = users;
    }

    @Override
    public int getCount() {
        return users.size();
    }

    @Override
    public Object getItem(int position) {
        return users.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Получаем данные из коллекции
        Date begin = new Date();
        User u = users.get(position);

        // Создаём разметку (контейнер)
        if (convertView == null) {
            convertView = LayoutInflater.from(ctx).inflate(R.layout.useritem, parent, false);
        }

        // Получаем ссылки на элементы интерфейса
        ImageView ivUserpic = convertView.findViewById(R.id.userpic);
        TextView tvName = convertView.findViewById(R.id.name);
        TextView tvPhone = convertView.findViewById(R.id.phone);

        // Задаём содержание
        tvName.setText(u.name);
        tvPhone.setText(u.phoneNumber);

        // Устанавливаем изображение пользователя в зависимости от пола
        switch (u.sex) {
            case MAN:
                ivUserpic.setImageResource(R.drawable.user_man);
                break;
            case WOMAN:
                ivUserpic.setImageResource(R.drawable.user_woman);
                break;
            case UNKNOWN:
                ivUserpic.setImageResource(R.drawable.user_unknow);
                break;
        }

        // Устанавливаем цвет фона для выделенного элемента
        if (position == selectedPosition) {
            convertView.setBackgroundColor(Color.LTGRAY);
        } else {
            convertView.setBackgroundColor(Color.TRANSPARENT); // Обычный цвет фона
        }

        // Обработка нажатия на элемент
        convertView.setOnClickListener(v -> {
            // Если кликнули на уже выделенный элемент - убираем выделение
            if (selectedPosition == position) {
                selectedPosition = -1;
            } else {
                selectedPosition = position; // Обновляем выделенный элемент
            }
            notifyDataSetChanged(); // Обновляем адаптер, чтобы изменения отразились
        });

        Date finish = new Date();
        Log.d("mytag", "getView time: " + (finish.getTime() - begin.getTime()));
        return convertView;
    }

    public void sortByName() {
        Collections.sort(users, new Comparator<User>() {
            @Override
            public int compare(User u1, User u2) {
                return u1.name.compareTo(u2.name);
            }
        });
        notifyDataSetChanged();
    }

    public void addUser(User newUser) {
        users.add(newUser);
        notifyDataSetChanged();
    }

    public void sortByPhoneNumber() {
        Collections.sort(users, new Comparator<User>() {
            @Override
            public int compare(User u1, User u2) {
                return u1.phoneNumber.compareTo(u2.phoneNumber);
            }
        });
        notifyDataSetChanged();
    }

    public void sortBySex() {
        Collections.sort(users, new Comparator<User>() {
            @Override
            public int compare(User u1, User u2) {
                return u1.sex.compareTo(u2.sex);
            }
        });
        notifyDataSetChanged();
    }
}
