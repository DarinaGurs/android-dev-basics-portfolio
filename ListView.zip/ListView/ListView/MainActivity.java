package com.example.arrayadapter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import com.example.arrayadapter.R;
import com.example.arrayadapter.User;
import com.example.arrayadapter.UserListAdapter;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    UserListAdapter adapter;
    ListView listView;
    EditText inputName, inputPhone;
    Spinner inputSex;
    String[] sexes = {"MAN", "WOMAN", "UNKNOWN"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputName = findViewById(R.id.inputName);
        inputPhone = findViewById(R.id.inputPhone);
        inputSex = findViewById(R.id.inputSex);

        // Создаем ArrayAdapter для Spinner
        ArrayAdapter<String> sexAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, sexes);
        sexAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        inputSex.setAdapter(sexAdapter);

        listView = findViewById(R.id.list);
        ArrayList<User> users = loadUsersFromJson();
        adapter = new UserListAdapter(this, users);
        listView.setAdapter(adapter);

        Button addUserButton = findViewById(R.id.addUserButton);
        addUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = inputName.getText().toString();
                String phoneNumber = inputPhone.getText().toString();
                String sex = inputSex.getSelectedItem().toString();

                User newUser = new User(name, phoneNumber, Sex.valueOf(sex));
                adapter.addUser(newUser); // Добавляем пользователя в адаптер
                inputName.setText(""); // Очищаем поле ввода
                inputPhone.setText("");
                inputSex.setSelection(0); // Очищаем поле ввода
            }
        });

        // Обработчики нажатий для кнопок
        Button sortByNameButton = findViewById(R.id.sort_by_name);
        Button sortByPhoneButton = findViewById(R.id.sort_by_phone);
        Button sortBySexButton = findViewById(R.id.sort_by_sex);

        sortByNameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter.sortByName();
            }
        });

        sortByPhoneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter.sortByPhoneNumber();
            }
        });

        sortBySexButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter.sortBySex();
            }
        });
    }

    private ArrayList<User> loadUsersFromJson() {
        ArrayList<User> users = new ArrayList<>();
        try {
            // Получаем InputStream для файла users.json
            InputStream inputStream = getAssets().open("users.json");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            Gson gson = new Gson();
            Type userListType = new TypeToken<ArrayList<User>>() {}.getType();
            users = gson.fromJson(reader, userListType);
        } catch (IOException e) {
            Log.e("MainActivity", "Ошибка загрузки данных", e);
        }
        return users;
    }

}