package com.example.airticketsbooking;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.text.format.DateUtils;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    TextView departureDateLabel;
    TextView arrivalDateLabel;
    Calendar departureDate = Calendar.getInstance();
    Calendar arrivalDate = Calendar.getInstance();
    EditText adultCountTickets, childCountTickets, infantCountTickets;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Spinner spinnerDepartureCity = findViewById(R.id.spinnerDepartureCity);
        Spinner spinnerArrivalCity = findViewById(R.id.spinnerArrivalCity);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.cities, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerDepartureCity.setAdapter(adapter);
        spinnerArrivalCity.setAdapter(adapter);

        departureDateLabel = findViewById(R.id.departureDateLabel);
        arrivalDateLabel = findViewById(R.id.arrivalDateLabel);
        setInitialDateTime();

        adultCountTickets = findViewById(R.id.ticketCountAdultInput);
        childCountTickets = findViewById(R.id.ticketCountChildInput);
        infantCountTickets = findViewById(R.id.ticketCountInfantInput);

        adultCountTickets.setInputType(InputType.TYPE_CLASS_NUMBER);
        childCountTickets.setInputType(InputType.TYPE_CLASS_NUMBER);
        infantCountTickets.setInputType(InputType.TYPE_CLASS_NUMBER);

    }

    public void setDepartureDate (View v){
        new DatePickerDialog(MainActivity.this, departureDateSetListener,
                departureDate.get(Calendar.YEAR),
                departureDate.get(Calendar.MONTH),
                departureDate.get(Calendar.DAY_OF_MONTH)).show();
        }

    public void setArrivalDate (View v){
        new DatePickerDialog(MainActivity.this, arrivalDateSetListener,
                arrivalDate.get(Calendar.YEAR),
                arrivalDate.get(Calendar.MONTH),
                arrivalDate.get(Calendar.DAY_OF_MONTH)).show();
    }



    // установка начальных даты и времени
    private void setInitialDateTime () {
        departureDateLabel.setText(DateUtils.formatDateTime(this,
                departureDate.getTimeInMillis(),
                    DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_YEAR));
            arrivalDateLabel.setText(DateUtils.formatDateTime(this,
                    arrivalDate.getTimeInMillis(),
                    DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_YEAR));
        }
    // Обработчик выбора даты для вылета
    DatePickerDialog.OnDateSetListener departureDateSetListener = new DatePickerDialog.OnDateSetListener() {
                public void onDateSet(DatePicker view, int year, int month, int day) {
                    departureDate.set(Calendar.YEAR, year);
                    departureDate.set(Calendar.MONTH, month);
                    departureDate.set(Calendar.DAY_OF_MONTH, day);
                    setInitialDateTime(); // Обновляем вид
                }
            };

    // Обработчик выбора даты для прибытия
    DatePickerDialog.OnDateSetListener arrivalDateSetListener = new DatePickerDialog.OnDateSetListener() {
                public void onDateSet(DatePicker view, int year, int month, int day) {
                    arrivalDate.set(Calendar.YEAR, year);
                    arrivalDate.set(Calendar.MONTH, month);
                    arrivalDate.set(Calendar.DAY_OF_MONTH, day);
                    setInitialDateTime(); // Обновляем вид
                }
            };
    }


