package com.example.arrayadapter;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ArrayList<String> names = new ArrayList<>();
    ListView lv;
    CustomAdapter adapter;
    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        lv = findViewById(R.id.list);
        adapter = new CustomAdapter(this, names); // Используем кастомный адаптер
        lv.setAdapter(adapter);

        // Генерация случайных людей из ресурсов
        String[] firstNames = getResources().getStringArray(R.array.first_names);
        String[] lastNames = getResources().getStringArray(R.array.last_names);

        for (int i = 0; i < 5; i++) {
            String randomName = firstNames[random.nextInt(firstNames.length)] + " " + lastNames[random.nextInt(lastNames.length)];
            names.add(randomName);
        }

        // Обновление адаптера
        adapter.notifyDataSetChanged();

        // Обработка нажатий на элементы списка
        lv.setOnItemClickListener((parent, view, position, id) -> {
            adapter.setSelectedIndex(position); // Устанавливаем выделенный элемент
        });

        // Кнопка добавления элемента списка
        Button addButton = findViewById(R.id.add_button);
        addButton.setOnClickListener(v -> {
            String newName = firstNames[random.nextInt(firstNames.length)] + " " + lastNames[random.nextInt(lastNames.length)];
            names.add(newName);
            adapter.notifyDataSetChanged();
            Toast.makeText(MainActivity.this, "Добавлено: " + newName, Toast.LENGTH_SHORT).show();
        });

        // Кнопка сортировки списка
        Button sortButton = findViewById(R.id.sort_button);
        sortButton.setOnClickListener(v -> {
            Collections.sort(names);
            adapter.notifyDataSetChanged();
            Toast.makeText(MainActivity.this, "Список отсортирован", Toast.LENGTH_SHORT).show();
        });
    }
}